import React, { useState } from "react";
import { Link } from "react-router-dom";
import {
  ChevronDown,
  ChevronUp,
  Shield,
  Briefcase,
  HeartHandshake,
  Wallet,
} from "lucide-react";

const benefits = [
  {
    title: "Gratuity",
    icon: <Wallet size={20} />,
    category: "Financial",
    content: (
      <>
        <p className="text-gray-700 leading-7">
          It is a defined benefit plan and is one of the many retirement
          benefits offered by the employer to the employee upon leaving the
          job. An individual who has worked in an organization for a minimum
          period of 5 years is eligible for this benefit.
        </p>

        <p className="mt-3 text-gray-700 leading-7">
          JNNCE is extending gratuity of{" "}
          <strong>Rs. 20,00,000/-</strong> (maximum amount) to all its
          employees as per Government of India notification.
        </p>
      </>
    ),
  },

  {
    title: "Employee Provident Fund & Employee Pension Scheme",
    icon: <Briefcase size={20} />,
    category: "Financial",
    content: (
      <>
        <p className="text-gray-700 leading-7">
          Employee Provident Fund (EPF) and Employee Pension Scheme (EPS) are
          provided to eligible employees as per Central Government norms.
        </p>

        <p className="mt-3 text-gray-700 leading-7">
          Under EPF, 12% of employee salary is contributed towards provident
          fund, while the employer also contributes according to government
          rules.
        </p>

        <p className="mt-3 text-gray-700 leading-7">
          JNNCE extends EPF & EPS benefits to all eligible employees.
        </p>
      </>
    ),
  },

  {
    title: "Employee State Insurance Corporation",
    icon: <Shield size={20} />,
    category: "Insurance",
    content: (
      <>
        <p className="text-gray-700 leading-7">
          Employees’ State Insurance (ESI) is a comprehensive social security
          scheme that provides medical and financial support during sickness,
          maternity, injury, or disability.
        </p>

        <p className="mt-3 text-gray-700 leading-7">
          JNNCE provides ESI facility for employees earning less than{" "}
          <strong>Rs. 21,000/- per month.</strong>
        </p>
      </>
    ),
  },

  {
    title: "Group Personal Accident Policy",
    icon: <HeartHandshake size={20} />,
    category: "Insurance",
    content: (
      <>
        <p className="text-gray-700 leading-7">
          All JNNCE employees are covered under Group Personal Accident
          Insurance with a sum assured of{" "}
          <strong>Rs. 6,00,000/-</strong>.
        </p>

        <p className="mt-3 text-gray-700 leading-7">
          The policy also covers hospitalization expenses up to{" "}
          <strong>Rs. 1,00,000/-</strong> and OPD treatment up to{" "}
          <strong>Rs. 20,000/-</strong>.
        </p>

        <a
          href="https://jnnce.ac.in/jnndemo/accidentalinsurance.html"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block mt-4 text-blue-700 font-medium hover:underline"
        >
          View More Details →
        </a>
      </>
    ),
  },

  {
    title: "Maternity Benefit",
    icon: <HeartHandshake size={20} />,
    category: "Leave Benefits",
    content: (
      <>
        <p className="text-gray-700 leading-7">
          Lady employees can avail{" "}
          <strong>180 days of maternity leave</strong> with full salary.
        </p>

        <p className="mt-3 text-gray-700 leading-7">
          JNNCE extends maternity leave benefits to eligible employees as per
          Government notification.
        </p>
      </>
    ),
  },

  {
    title: "Paternity Benefit",
    icon: <HeartHandshake size={20} />,
    category: "Leave Benefits",
    content: (
      <>
        <p className="text-gray-700 leading-7">
          Male employees can avail{" "}
          <strong>14 days of paternity leave</strong> with full salary.
        </p>

        <p className="mt-3 text-gray-700 leading-7">
          JNNCE extends paternity leave benefits to eligible employees as per
          Government notification.
        </p>
      </>
    ),
  },

  {
    title: "Advance Salary Benefits",
    icon: <Wallet size={20} />,
    category: "Financial",
    content: (
      <>
        <p className="text-gray-700 leading-7">
          JNNCE provides advance salary benefits for medical emergencies,
          marriage, children education, and other approved reasons.
        </p>

        <p className="mt-3 text-gray-700 leading-7">
          Maximum advance amount is{" "}
          <strong>3 months salary or Rs. 50,000/-</strong>, whichever is lower.
        </p>

        <p className="mt-3 text-gray-700 leading-7">
          The amount will be recovered in 20 monthly installments.
        </p>
      </>
    ),
  },
];

const categories = [
  "All Benefits",
  "Financial",
  "Insurance",
  "Leave Benefits",
];

const EmpBenefits = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  const [activeCategory, setActiveCategory] = useState("All Benefits");

  const toggleAccordion = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  const filteredBenefits =
    activeCategory === "All Benefits"
      ? benefits
      : benefits.filter((item) => item.category === activeCategory);

  return (
    <div className="bg-[#f7f5f2] text-gray-800 pt-[170px] lg:pt-[80px]">
      {/* Banner */}
      <section className="bg-[#0D1B3E] text-white py-10 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[linear-gradient(135deg,#ffffff22_25%,transparent_25%,transparent_50%,#ffffff22_50%,#ffffff22_75%,transparent_75%,transparent)] bg-[length:40px_40px]" />

        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <h1 className="text-4xl font-bold">Employee Benefits</h1>

          <p className="mt-3 text-gray-200 max-w-2xl">
            JNNCE provides comprehensive welfare schemes and employee support
            programs to ensure professional growth, security, and wellbeing.
          </p>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-10">
            {[
              { value: "7+", label: "Benefit Schemes" },
              { value: "20L", label: "Maximum Gratuity" },
              { value: "180", label: "Maternity Leave Days" },
              { value: "100%", label: "Employee Support" },
            ].map((item, index) => (
              <div
                key={index}
                className="bg-white/10 backdrop-blur-sm border border-white/10 rounded-2xl p-6 text-center"
              >
                <h3 className="text-3xl font-bold text-yellow-400">
                  {item.value}
                </h3>

                <p className="text-gray-200 mt-2 text-sm">{item.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="max-w-7xl mx-auto px-4 py-14">
        {/* Filter Buttons */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-6 py-3 rounded-full border transition-all duration-300 font-semibold text-sm shadow-sm ${
                activeCategory === category
                  ? "bg-[#0D1B3E] text-white border-[#0D1B3E] shadow-lg"
                  : "bg-white text-gray-700 border-gray-300 hover:bg-[#0D1B3E] hover:text-white"
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Content */}
          <div className="lg:col-span-3 space-y-5">
            {filteredBenefits.map((item, index) => (
              <div
                key={index}
                className="bg-white rounded-2xl shadow border overflow-hidden"
              >
                <button
                  onClick={() => toggleAccordion(index)}
                  className="w-full flex items-center justify-between px-6 py-5 hover:bg-gray-50 transition"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-11 h-11 rounded-xl bg-[#0D1B3E] text-white flex items-center justify-center">
                      {item.icon}
                    </div>

                    <div className="text-left">
                      <h3 className="font-semibold text-[#0D1B3E] text-lg">
                        {item.title}
                      </h3>

                      <p className="text-sm text-gray-500 mt-1">
                        {item.category}
                      </p>
                    </div>
                  </div>

                  <div className="text-[#0D1B3E]">
                    {openIndex === index ? (
                      <ChevronUp size={22} />
                    ) : (
                      <ChevronDown size={22} />
                    )}
                  </div>
                </button>

                {openIndex === index && (
                  <div className="px-6 pb-6 border-t bg-gray-50/50">
                    <div className="pt-5">{item.content}</div>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Sidebar */}
          <aside className="space-y-4">
            <div className="bg-white shadow rounded-2xl border overflow-hidden sticky top-32">
              <div className="bg-[#0D1B3E] text-white px-5 py-4 font-semibold text-lg">
                Navigation
              </div>

              <div className="divide-y">
                <Link
                  to="/aboutjnnce"
                  className="block px-5 py-4 hover:bg-gray-50 transition"
                >
                  About JNNCE
                </Link>

                <Link
                  to="/vision"
                  className="block px-5 py-4 hover:bg-gray-50 transition"
                >
                  Vision & Mission
                </Link>

                <Link
                  to="/aboutnes"
                  className="block px-5 py-4 hover:bg-gray-50 transition"
                >
                  About NES
                </Link>

                <Link
                  to="/ranking"
                  className="block px-5 py-4 hover:bg-gray-50 transition"
                >
                  Accreditation
                </Link>

                <Link
                  to="/contact"
                  className="block px-5 py-4 hover:bg-gray-50 transition"
                >
                  Contact Us
                </Link>
              </div>
            </div>
          </aside>
        </div>
      </section>
    </div>
  );
};

export default EmpBenefits;